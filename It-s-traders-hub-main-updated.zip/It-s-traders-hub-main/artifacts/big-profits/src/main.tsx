import { createRoot } from "react-dom/client";
import { setBaseUrl } from "@workspace/api-client-react";
import App from "./App";
import "./index.css";

// Every generated API client path already starts with "/api/..." (it mirrors
// the Express mount point on the backend), so strip a trailing "/api" from
// VITE_API_URL here to avoid ending up with ".../api/api/auth/login".
const rawApiUrl = import.meta.env.VITE_API_URL ?? "";
setBaseUrl(rawApiUrl.replace(/\/api\/?$/, ""));

createRoot(document.getElementById("root")!).render(<App />);
